import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  ArrowUp,
  Menu,
  X,
  Scale,
  Users,
  FileText,
  Home,
  Briefcase,
  HardHat,
  ShieldCheck,
  Gavel,
  ClipboardCheck,
  FilePlus,
  Award,
  BookOpen,
  Send as Instagram,
  ChevronDown,
  Calendar,
  Star,
  Navigation,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import heroAsset from "@/assets/attorney-hero.png.asset.json";
const heroImg = heroAsset.url;
import art1 from "@/assets/article-1.jpg";
import art2 from "@/assets/article-2.jpg";
import art3 from "@/assets/article-3.jpg";

export const Route = createFileRoute("/")({
  component: Landing,
});

const WHATSAPP = "https://wa.me/989113940378";
const PHONE = "09113940378";
const PHONE_INTL = "+989113940378";
const EMAIL = "info@kamorati.com";
const ADDRESS = "تنکابن، سه‌راه خرم‌آباد، مازندران";
const MAPS_QUERY = "https://www.google.com/maps?q=Tonekabon+Khorramabad+Junction";
const MAPS_EMBED =
  "https://www.google.com/maps?q=Tonekabon+Khorramabad+Junction&hl=fa&z=15&output=embed";

const NAV = [
  { href: "#home", label: "خانه" },
  { href: "#about", label: "درباره" },
  { href: "#practice", label: "حوزه‌های تخصصی" },
  { href: "#achievements", label: "افتخارات" },
  { href: "#articles", label: "مقالات" },
  { href: "#contact", label: "تماس" },
];

const STATS = [
  { value: 15, suffix: "+", label: "سال تجربه" },
  { value: 1200, suffix: "+", label: "پرونده موفق" },
  { value: 980, suffix: "+", label: "موکل راضی" },
  { value: 24, suffix: "/۷", label: "پاسخگویی" },
];

const PRACTICE = [
  { icon: Gavel, title: "حقوق کیفری", desc: "دفاع تخصصی در پرونده‌های کیفری و جرایم عمومی." },
  { icon: Users, title: "حقوق خانواده", desc: "طلاق، مهریه، حضانت و امور مربوط به خانواده." },
  { icon: FileText, title: "حقوق قراردادها", desc: "تنظیم، بررسی و دعاوی مربوط به قراردادها." },
  { icon: Home, title: "املاک", desc: "دعاوی ملکی، خلع ید، الزام به تنظیم سند و مبایعه‌نامه." },
  { icon: Briefcase, title: "حقوق تجارت", desc: "دعاوی تجاری، شرکت‌ها، چک و اسناد تجاری." },
  { icon: HardHat, title: "حقوق کار", desc: "روابط کارگر و کارفرما و شکایات اداره کار." },
  { icon: ShieldCheck, title: "بیمه", desc: "دعاوی بیمه‌ای، دیه و مطالبات از شرکت‌های بیمه." },
  { icon: Scale, title: "داوری", desc: "حل و فصل اختلافات از طریق داوری تخصصی." },
  { icon: ClipboardCheck, title: "اجرای احکام", desc: "پیگیری اجرای احکام حقوقی و کیفری." },
  { icon: FilePlus, title: "تنظیم قرارداد", desc: "تنظیم قراردادهای حرفه‌ای و بدون ابهام حقوقی." },
];

const ACHIEVEMENTS = [
  {
    icon: Award,
    title: "پروانه وکالت پایه یک دادگستری",
    desc: "دارنده پروانه رسمی وکالت پایه یک از کانون وکلای دادگستری.",
  },
  {
    icon: BookOpen,
    title: "گواهینامه‌های تخصصی حقوقی",
    desc: "دارای گواهینامه‌های تخصصی در حوزه‌های کیفری، خانواده و املاک.",
  },
  {
    icon: ShieldCheck,
    title: "عضویت در کانون وکلا",
    desc: "عضو رسمی کانون وکلای دادگستری استان مازندران.",
  },
  {
    icon: CheckCircle2,
    title: "پرونده‌های موفق",
    desc: "بیش از ۱۲۰۰ پرونده موفق در دادگاه‌ها و مراجع قضایی سراسر کشور.",
  },
];

const ARTICLES = [
  {
    img: art1,
    date: "۱۴۰۳/۰۸/۱۲",
    title: "بررسی شرایط اعمال ماده ۴۷۷ قانون آیین دادرسی کیفری",
    summary:
      "ماده ۴۷۷ یکی از مهم‌ترین ابزارهای اعاده دادرسی است. در این مقاله شرایط، مراحل و نکات کاربردی این ماده بررسی می‌شود.",
  },
  {
    img: art2,
    date: "۱۴۰۳/۰۷/۲۸",
    title: "نکات حقوقی تنظیم سند ازدواج و مهریه",
    summary:
      "قبل از عقد باید به چه نکاتی در تنظیم مهریه و شروط ضمن عقد توجه کنید؟ راهنمای کامل حقوقی برای زوجین.",
  },
  {
    img: art3,
    date: "۱۴۰۳/۰۷/۱۰",
    title: "چالش‌های حقوقی خرید و فروش ملک در تنکابن",
    summary:
      "معاملات ملکی در شهرهای شمالی نکات خاص خود را دارد. در این نوشتار مهم‌ترین ریسک‌های حقوقی را مرور می‌کنیم.",
  },
];

const TESTIMONIALS = [
  {
    name: "علی محمدی",
    role: "موکل پرونده کیفری",
    text: "دقت و پیگیری آقای کمراتی در پرونده من واقعاً بی‌نظیر بود. با اعتماد کامل ایشان را توصیه می‌کنم.",
  },
  {
    name: "مریم رضایی",
    role: "موکل پرونده خانواده",
    text: "برخورد حرفه‌ای، توضیحات شفاف و نتیجه‌ای فراتر از انتظار. سپاسگزارم.",
  },
  {
    name: "حسین کاظمی",
    role: "کارآفرین",
    text: "برای تنظیم قراردادهای شرکتی به ایشان مراجعه کردم. تخصص و مسئولیت‌پذیری بالایی دارند.",
  },
  {
    name: "زهرا حسینی",
    role: "موکل پرونده ملکی",
    text: "پرونده پیچیده ما را با صبوری و دانش حقوقی بالا به سرانجام رساندند.",
  },
  {
    name: "امیر صادقی",
    role: "موکل پرونده تجاری",
    text: "بهترین انتخاب برای یک وکیل مطمئن و متعهد در تنکابن. پیشنهاد صد در صد.",
  },
];

const FAQS = [
  {
    q: "هزینه مشاوره حقوقی چقدر است؟",
    a: "هزینه مشاوره بسته به موضوع و پیچیدگی پرونده متفاوت است. برای اطلاع دقیق از طریق واتساپ یا تماس تلفنی با دفتر در ارتباط باشید.",
  },
  {
    q: "آیا امکان مشاوره تلفنی یا آنلاین وجود دارد؟",
    a: "بله. مشاوره از طریق واتساپ، تماس تلفنی و به صورت آنلاین برای موکلان خارج از تنکابن قابل ارائه است.",
  },
  {
    q: "قبول وکالت در چه شهرهایی انجام می‌شود؟",
    a: "قبول وکالت در تمامی مراجع قضایی سراسر کشور با تمرکز بر استان مازندران و به‌ویژه شهر تنکابن انجام می‌گیرد.",
  },
  {
    q: "چگونه پرونده خود را ثبت کنم؟",
    a: "ابتدا از طریق واتساپ یا تماس، وقت مشاوره دریافت کنید. پس از بررسی، در صورت پذیرش، قرارداد وکالت تنظیم خواهد شد.",
  },
  {
    q: "زمان پاسخگویی چقدر است؟",
    a: "پیام‌های واتساپ در کوتاه‌ترین زمان ممکن و معمولاً کمتر از چند ساعت پاسخ داده می‌شوند.",
  },
];

function toFa(n: number) {
  return n.toLocaleString("fa-IR");
}

/* ------------------------- Components ------------------------- */

function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/85 backdrop-blur-md border-b border-border shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="container-luxe flex h-16 items-center justify-between gap-4">
        <a href="#home" className="flex items-center gap-2 min-w-0">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground shrink-0">
            <Scale className="h-4 w-4 text-gold" />
          </span>
          <span className="font-bold text-primary truncate">
            دفتر وکالت <span className="text-gradient-gold">کمراتی</span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-7">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors relative after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-gold after:transition-all hover:after:w-full"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:inline-flex btn-gold btn-gold-hover text-sm"
          >
            <MessageCircle className="h-4 w-4" />
            مشاوره فوری در واتساپ
          </a>
          <button
            aria-label="باز کردن منو"
            className="lg:hidden grid h-10 w-10 place-items-center rounded-lg border border-border text-primary"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-background border-t border-border">
          <div className="container-luxe py-4 flex flex-col gap-2">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="py-2 text-foreground/80 hover:text-primary font-medium"
              >
                {n.label}
              </a>
            ))}
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-gold btn-gold-hover justify-center mt-2"
            >
              <MessageCircle className="h-4 w-4" />
              مشاوره فوری در واتساپ
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      {/* animated backdrop */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-secondary/60 via-background to-background" />
      <div className="absolute -z-10 top-24 -right-24 h-96 w-96 rounded-full bg-gold/20 blur-3xl animate-glow-pulse" />
      <div
        className="absolute -z-10 bottom-0 -left-24 h-96 w-96 rounded-full bg-primary/10 blur-3xl animate-glow-pulse"
        style={{ animationDelay: "2s" }}
      />

      <div className="container-luxe grid gap-12 lg:grid-cols-2 items-center">
        <div className="animate-fade-up">
          <span className="eyebrow">
            <Sparkles className="h-4 w-4" />
            وکیل پایه یک دادگستری
          </span>
          <h1 className="mt-4 text-4xl md:text-6xl font-black leading-tight text-primary">
            سید داود کمراتی
            <span className="block mt-2 text-gradient-gold">همراه شما در مسیر عدالت</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-xl">
            متخصص دعاوی کیفری، خانواده، قراردادها و امور ملکی. با بیش از ۱۵ سال تجربه، پرونده شما را
            با دقت، تعهد و پیگیری مستمر تا حصول نتیجه دنبال می‌کنیم.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-gold btn-gold-hover"
            >
              <MessageCircle className="h-5 w-5" />
              مشاوره فوری در واتساپ
            </a>
            <a href={`tel:${PHONE_INTL}`} className="btn-outline-luxe">
              <Phone className="h-5 w-5" />
              تماس مستقیم
            </a>
            <a href="#about" className="btn-outline-luxe">
              <FileText className="h-5 w-5" />
              مشاهده رزومه
            </a>
          </div>

          <div className="mt-10 grid grid-cols-3 gap-4 max-w-md">
            {STATS.slice(0, 3).map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-2xl md:text-3xl font-black text-primary">
                  {toFa(s.value)}
                  {s.suffix}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative animate-fade-up" style={{ animationDelay: "0.2s" }}>
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-gold/40 to-primary/20 blur-2xl animate-glow-pulse" />
          <div className="relative rounded-3xl overflow-hidden border border-border shadow-[var(--shadow-luxe)]">
            <img
              src={heroImg}
              alt="سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن"
              width={1280}
              height={1600}
              fetchPriority="high"
              className="w-full h-auto object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary/90 via-primary/40 to-transparent p-6">
              <div className="flex items-center gap-3 text-primary-foreground">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gold text-primary">
                  <Scale className="h-5 w-5" />
                </span>
                <div>
                  <div className="font-bold">سید داود کمراتی</div>
                  <div className="text-sm opacity-90">وکیل پایه یک دادگستری</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function useInView<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setSeen(true);
            obs.disconnect();
          }
        });
      },
      { threshold: 0.2 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, seen };
}

function Counter({ value, suffix }: { value: number; suffix?: string }) {
  const { ref, seen } = useInView<HTMLDivElement>();
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!seen) return;
    const start = performance.now();
    const dur = 1400;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [seen, value]);
  return (
    <div ref={ref} className="text-3xl md:text-4xl font-black text-primary">
      {toFa(n)}
      {suffix}
    </div>
  );
}

function SectionHeader({ eyebrow, title, desc }: { eyebrow: string; title: string; desc?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center mb-12">
      <span className="eyebrow justify-center">
        <span className="h-px w-8 bg-gold" />
        {eyebrow}
        <span className="h-px w-8 bg-gold" />
      </span>
      <h2 className="mt-4 text-3xl md:text-4xl font-black text-primary">{title}</h2>
      {desc && <p className="mt-3 text-muted-foreground leading-relaxed">{desc}</p>}
    </div>
  );
}

function About() {
  return (
    <section id="about" className="section-y bg-secondary/40">
      <div className="container-luxe grid gap-10 lg:grid-cols-5 items-center">
        <div className="lg:col-span-3">
          <span className="eyebrow">
            <span className="h-px w-8 bg-gold" />
            درباره وکیل
          </span>
          <h2 className="mt-4 text-3xl md:text-4xl font-black text-primary leading-tight">
            حقوقدانی متعهد، در کنار شما تا حصول نتیجه
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-loose">
            سید داود کمراتی، وکیل پایه یک دادگستری با بیش از ۱۵ سال تجربه موفق در پرونده‌های کیفری،
            خانواده و قراردادها. ایشان با تعهد، صداقت، دقت و پیگیری مستمر، همواره همراهی مطمئن
            برای موکلان خود بوده‌اند.
          </p>

          <ul className="mt-6 grid sm:grid-cols-2 gap-3">
            {[
              "پاسخگویی سریع و شفاف",
              "تعهد به منافع موکل",
              "پیگیری تخصصی تا نتیجه نهایی",
              "تجربه در دادگاه‌های سراسر کشور",
            ].map((f) => (
              <li key={f} className="flex items-center gap-2 text-primary">
                <CheckCircle2 className="h-5 w-5 text-gold shrink-0" />
                <span className="font-medium">{f}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          {STATS.map((s) => (
            <div key={s.label} className="card-luxe text-center">
              <Counter value={s.value} suffix={s.suffix} />
              <div className="mt-2 text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Practice() {
  return (
    <section id="practice" className="section-y">
      <div className="container-luxe">
        <SectionHeader
          eyebrow="حوزه‌های تخصصی"
          title="خدمات حقوقی تخصصی"
          desc="پوشش کامل حوزه‌های حقوقی با تجربه‌ای طولانی در پرونده‌های پیچیده."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PRACTICE.map((p, i) => (
            <div
              key={p.title}
              className="card-luxe group"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="flex items-center gap-4">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/30 text-primary transition-transform group-hover:scale-110">
                  <p.icon className="h-6 w-6" />
                </span>
                <h3 className="font-bold text-lg text-primary">{p.title}</h3>
              </div>
              <p className="mt-4 text-muted-foreground leading-relaxed text-sm">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Achievements() {
  return (
    <section id="achievements" className="section-y bg-primary text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_20%_20%,var(--color-gold)_0,transparent_40%),radial-gradient(circle_at_80%_80%,var(--color-gold)_0,transparent_40%)]" />
      <div className="container-luxe relative">
        <div className="mx-auto max-w-2xl text-center mb-12">
          <span className="eyebrow justify-center text-gold">
            <span className="h-px w-8 bg-gold" />
            افتخارات
            <span className="h-px w-8 bg-gold" />
          </span>
          <h2 className="mt-4 text-3xl md:text-4xl font-black">مدارک، عضویت‌ها و دستاوردها</h2>
        </div>

        <ol className="relative grid gap-6 md:grid-cols-2">
          {ACHIEVEMENTS.map((a) => (
            <li
              key={a.title}
              className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 transition-all hover:border-gold/50 hover:-translate-y-1"
            >
              <div className="flex items-start gap-4">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gold text-primary">
                  <a.icon className="h-6 w-6" />
                </span>
                <div>
                  <h3 className="font-bold text-lg">{a.title}</h3>
                  <p className="mt-2 text-primary-foreground/80 text-sm leading-relaxed">
                    {a.desc}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Articles() {
  return (
    <section id="articles" className="section-y">
      <div className="container-luxe">
        <SectionHeader
          eyebrow="مقالات حقوقی"
          title="آخرین نوشته‌ها"
          desc="مطالب کاربردی و به‌روز برای آشنایی بیشتر با مسائل حقوقی روز."
        />

        <div className="grid gap-6 md:grid-cols-3">
          {ARTICLES.map((a) => (
            <article
              key={a.title}
              className="group rounded-2xl overflow-hidden border border-border bg-card transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-luxe)]"
            >
              <div className="aspect-[3/2] overflow-hidden">
                <img
                  src={a.img}
                  alt={a.title}
                  width={960}
                  height={640}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="h-4 w-4 text-gold" />
                  {a.date}
                </div>
                <h3 className="mt-3 font-bold text-lg text-primary leading-snug group-hover:text-gold transition-colors">
                  {a.title}
                </h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{a.summary}</p>
                <button
                  type="button"
                  className="mt-5 inline-flex items-center gap-1 text-sm font-bold text-primary hover:text-gold transition-colors"
                >
                  ادامه مطلب
                  <ChevronDown className="h-4 w-4 -rotate-90 rtl-flip" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % TESTIMONIALS.length), 5000);
    return () => clearInterval(t);
  }, []);
  const t = TESTIMONIALS[i];

  return (
    <section className="section-y bg-secondary/40">
      <div className="container-luxe">
        <SectionHeader eyebrow="نظرات موکلان" title="اعتماد آن‌ها، افتخار ماست" />

        <div className="mx-auto max-w-3xl">
          <div className="card-luxe text-center relative">
            <div className="flex justify-center gap-1 text-gold">
              {Array.from({ length: 5 }).map((_, k) => (
                <Star key={k} className="h-5 w-5 fill-current" />
              ))}
            </div>
            <p className="mt-6 text-lg md:text-xl text-primary leading-loose font-medium">
              «{t.text}»
            </p>
            <div className="mt-6">
              <div className="font-bold text-primary">{t.name}</div>
              <div className="text-sm text-muted-foreground">{t.role}</div>
            </div>
          </div>

          <div className="mt-6 flex justify-center gap-2">
            {TESTIMONIALS.map((_, k) => (
              <button
                key={k}
                aria-label={`نظر شماره ${toFa(k + 1)}`}
                onClick={() => setI(k)}
                className={`h-2 rounded-full transition-all ${
                  k === i ? "w-8 bg-gold" : "w-2 bg-border hover:bg-gold/60"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="section-y">
      <div className="container-luxe">
        <SectionHeader eyebrow="سوالات متداول" title="پاسخ به پرتکرارترین پرسش‌ها" />

        <div className="mx-auto max-w-3xl">
          {FAQS.map((f, idx) => {
            const isOpen = open === idx;
            return (
              <div
                key={f.q}
                className="border-b border-border last:border-0 first:border-t"
              >
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between gap-4 py-5 text-right"
                >
                  <span className="font-bold text-primary">{f.q}</span>
                  <ChevronDown
                    className={`h-5 w-5 text-gold transition-transform ${
                      isOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ease-in-out ${
                    isOpen ? "grid-rows-[1fr] opacity-100 pb-5" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <p className="overflow-hidden text-muted-foreground leading-relaxed">{f.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: FAQS.map((f) => ({
              "@type": "Question",
              name: f.q,
              acceptedAnswer: { "@type": "Answer", text: f.a },
            })),
          }),
        }}
      />
    </section>
  );
}

function Contact() {
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") || "").trim();
    const phone = String(fd.get("phone") || "").trim();
    const email = String(fd.get("email") || "").trim();
    const subject = String(fd.get("subject") || "").trim();
    const message = String(fd.get("message") || "").trim();

    const errs: Record<string, string> = {};
    if (name.length < 2) errs.name = "لطفاً نام معتبر وارد کنید.";
    if (!/^0?9\d{9}$/.test(phone.replace(/\s|-/g, ""))) errs.phone = "شماره موبایل معتبر نیست.";
    if (email && !/^\S+@\S+\.\S+$/.test(email)) errs.email = "ایمیل معتبر نیست.";
    if (subject.length < 3) errs.subject = "موضوع را وارد کنید.";
    if (message.length < 10) errs.message = "پیام باید حداقل ۱۰ کاراکتر باشد.";

    setErrors(errs);
    if (Object.keys(errs).length) {
      setStatus("error");
      return;
    }
    setStatus("success");
    (e.currentTarget as HTMLFormElement).reset();
    setTimeout(() => setStatus("idle"), 5000);
  }

  const inputCls =
    "w-full rounded-lg border border-input bg-background px-4 py-3 text-sm focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/30 transition";

  return (
    <section id="contact" className="section-y bg-secondary/40">
      <div className="container-luxe">
        <SectionHeader
          eyebrow="ارتباط با ما"
          title="در تماس باشیم"
          desc="پاسخگوی سوالات حقوقی شما هستیم. فرم زیر را تکمیل کنید یا مستقیم تماس بگیرید."
        />

        <div className="grid gap-8 lg:grid-cols-5">
          <div className="lg:col-span-2 space-y-4">
            {[
              { icon: Phone, label: "تلفن", value: PHONE, href: `tel:${PHONE_INTL}` },
              { icon: MessageCircle, label: "واتساپ", value: "پیام مستقیم", href: WHATSAPP },
              { icon: Mail, label: "ایمیل", value: EMAIL, href: `mailto:${EMAIL}` },
              { icon: MapPin, label: "دفتر", value: ADDRESS, href: MAPS_QUERY },
            ].map((c) => (
              <a
                key={c.label}
                href={c.href}
                target={c.href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-gold/50 hover:shadow-[var(--shadow-luxe)] transition-all group"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/30 text-primary group-hover:scale-110 transition-transform">
                  <c.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground">{c.label}</div>
                  <div className="font-bold text-primary truncate">{c.value}</div>
                </div>
              </a>
            ))}
          </div>

          <form
            onSubmit={onSubmit}
            className="lg:col-span-3 rounded-2xl bg-card border border-border p-6 md:p-8 space-y-4"
            noValidate
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-primary mb-2">
                  نام و نام خانوادگی
                </label>
                <input id="name" name="name" className={inputCls} maxLength={80} required />
                {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-primary mb-2">
                  شماره تماس
                </label>
                <input
                  id="phone"
                  name="phone"
                  inputMode="tel"
                  className={inputCls}
                  maxLength={15}
                  required
                />
                {errors.phone && <p className="text-xs text-destructive mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-primary mb-2">
                  ایمیل (اختیاری)
                </label>
                <input id="email" name="email" type="email" className={inputCls} maxLength={120} />
                {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-primary mb-2">
                  موضوع
                </label>
                <input id="subject" name="subject" className={inputCls} maxLength={120} required />
                {errors.subject && (
                  <p className="text-xs text-destructive mt-1">{errors.subject}</p>
                )}
              </div>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-primary mb-2">
                پیام شما
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                className={inputCls}
                maxLength={1500}
                required
              />
              {errors.message && (
                <p className="text-xs text-destructive mt-1">{errors.message}</p>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3 justify-between">
              <button type="submit" className="btn-gold btn-gold-hover">
                ارسال پیام
              </button>
              {status === "success" && (
                <div className="flex items-center gap-2 text-sm text-primary">
                  <CheckCircle2 className="h-4 w-4 text-gold" />
                  پیام شما با موفقیت ارسال شد. به‌زودی با شما تماس می‌گیریم.
                </div>
              )}
            </div>
          </form>
        </div>

        {/* Map */}
        <div className="mt-12 rounded-2xl overflow-hidden border border-border shadow-[var(--shadow-luxe)] relative">
          <iframe
            title="نقشه دفتر وکالت — تنکابن، سه‌راه خرم‌آباد"
            src={MAPS_EMBED}
            width="100%"
            height="420"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full h-[420px] border-0"
          />
          <a
            href={MAPS_QUERY}
            target="_blank"
            rel="noopener noreferrer"
            className="absolute top-4 left-4 btn-gold btn-gold-hover text-sm"
          >
            <Navigation className="h-4 w-4" />
            مسیریابی
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8">
      <div className="container-luxe grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-white/10">
              <Scale className="h-4 w-4 text-gold" />
            </span>
            <span className="font-bold">
              دفتر وکالت <span className="text-gradient-gold">کمراتی</span>
            </span>
          </div>
          <p className="mt-4 text-sm text-primary-foreground/70 leading-relaxed max-w-md">
            دفتر وکالت سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن. متخصص در دعاوی کیفری،
            خانواده، قراردادها و امور ملکی.
          </p>
          <div className="mt-5 flex items-center gap-3">
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="واتساپ"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-gold hover:text-primary transition-colors"
            >
              <MessageCircle className="h-4 w-4" />
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="اینستاگرام"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-gold hover:text-primary transition-colors"
            >
              <Instagram className="h-4 w-4" />
            </a>
            <a
              href={`tel:${PHONE_INTL}`}
              aria-label="تماس"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-gold hover:text-primary transition-colors"
            >
              <Phone className="h-4 w-4" />
            </a>
            <a
              href={`mailto:${EMAIL}`}
              aria-label="ایمیل"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-gold hover:text-primary transition-colors"
            >
              <Mail className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-bold text-gold mb-4">دسترسی سریع</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/80">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="hover:text-gold transition-colors">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-gold mb-4">تماس با ما</h4>
          <ul className="space-y-3 text-sm text-primary-foreground/80">
            <li className="flex items-start gap-2">
              <MapPin className="h-4 w-4 text-gold shrink-0 mt-0.5" />
              <span>{ADDRESS}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-gold shrink-0" />
              <a href={`tel:${PHONE_INTL}`} className="hover:text-gold" dir="ltr">
                {PHONE}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-gold shrink-0" />
              <a href={`mailto:${EMAIL}`} className="hover:text-gold" dir="ltr">
                {EMAIL}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="container-luxe mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-primary-foreground/60">
        <span>© {toFa(new Date().getFullYear())} دفتر وکالت سید داود کمراتی. تمامی حقوق محفوظ است.</span>
        <span>طراحی شده با دقت و عشق به عدالت</span>
      </div>
    </footer>
  );
}

function FloatingActions() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const on = () => setVisible(window.scrollY > 400);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3">
      <a
        href={WHATSAPP}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="مشاوره در واتساپ"
        className="grid h-13 w-13 h-13 place-items-center rounded-full bg-[#25D366] text-white shadow-[var(--shadow-gold)] hover:scale-110 transition-transform"
        style={{ height: 56, width: 56 }}
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <a
        href={`tel:${PHONE_INTL}`}
        aria-label="تماس تلفنی"
        className="grid place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-luxe)] hover:scale-110 transition-transform"
        style={{ height: 56, width: 56 }}
      >
        <Phone className="h-5 w-5 text-gold" />
      </a>
      <button
        type="button"
        aria-label="بازگشت به بالا"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className={`grid place-items-center rounded-full bg-gold text-primary shadow-[var(--shadow-gold)] transition-all ${
          visible ? "opacity-100 scale-100" : "opacity-0 scale-75 pointer-events-none"
        }`}
        style={{ height: 56, width: 56 }}
      >
        <ArrowUp className="h-5 w-5" />
      </button>
    </div>
  );
}

function Landing() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:right-2 focus:z-[100] focus:bg-primary focus:text-primary-foreground focus:px-4 focus:py-2 focus:rounded"
      >
        پرش به محتوا
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <About />
        <Practice />
        <Achievements />
        <Articles />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}
