import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "سید داود کمراتی | وکیل پایه یک دادگستری در تنکابن" },
      {
        name: "description",
        content:
          "سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن با بیش از ۱۵ سال تجربه در پرونده‌های کیفری، خانواده، قراردادها، املاک و امور تجاری. مشاوره حقوقی تخصصی و پیگیری تا حصول نتیجه.",
      },
      {
        name: "keywords",
        content:
          "بهترین وکیل تنکابن, وکیل پایه یک دادگستری سید داود کمراتی, وکیل کیفری تنکابن, وکیل خانواده تنکابن, مشاوره حقوقی تنکابن",
      },
      { name: "author", content: "سید داود کمراتی" },
      { name: "theme-color", content: "#1a1a2e" },
      { property: "og:title", content: "سید داود کمراتی | وکیل پایه یک دادگستری در تنکابن" },
      {
        property: "og:description",
        content: "همراه شما در مسیر عدالت؛ مشاوره تخصصی در پرونده‌های کیفری، خانواده و املاک.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "fa_IR" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "سید داود کمراتی | وکیل پایه یک دادگستری در تنکابن" },
      {
        name: "twitter:description",
        content: "مشاوره حقوقی تخصصی در تنکابن — کیفری، خانواده، قراردادها و املاک.",
      },
      { name: "description", content: "سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن با بیش از ۱۵ سال تجربه در پرونده‌های کیفری، خانواده، قراردادها، املاک و امور تجاری. مشاوره حقوقی تخصصی و پیگیری تا حصول نتیجه." },
      { property: "og:description", content: "سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن با بیش از ۱۵ سال تجربه در پرونده‌های کیفری، خانواده، قراردادها، املاک و امور تجاری. مشاوره حقوقی تخصصی و پیگیری تا حصول نتیجه." },
      { name: "twitter:description", content: "سید داود کمراتی، وکیل پایه یک دادگستری در تنکابن با بیش از ۱۵ سال تجربه در پرونده‌های کیفری، خانواده، قراردادها، املاک و امور تجاری. مشاوره حقوقی تخصصی و پیگیری تا حصول نتیجه." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/733faf8d-55fe-46e9-bf75-91d2f46eedf7/id-preview-393a6666--31882257-35c2-4908-936b-1e64e102ac14.lovable.app-1783347171873.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/733faf8d-55fe-46e9-bf75-91d2f46eedf7/id-preview-393a6666--31882257-35c2-4908-936b-1e64e102ac14.lovable.app-1783347171873.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": ["Attorney", "LegalService", "LocalBusiness"],
          name: "دفتر وکالت سید داود کمراتی",
          description:
            "وکیل پایه یک دادگستری در تنکابن، متخصص دعاوی کیفری، خانواده، قراردادها و امور ملکی.",
          telephone: "+989113940378",
          email: "info@kamorati.com",
          areaServed: { "@type": "Place", name: "تنکابن، مازندران، ایران" },
          address: {
            "@type": "PostalAddress",
            streetAddress: "سه‌راه خرم‌آباد",
            addressLocality: "تنکابن",
            addressRegion: "مازندران",
            addressCountry: "IR",
          },
          priceRange: "$$",
          knowsLanguage: ["fa", "en"],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
